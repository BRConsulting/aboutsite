$(document).ready(function() {
  var aboutElement = $('div.about'), 
      aboutElementOffset = aboutElement.offset().top / 2, // Definindo o ponto de ativação da animação
      documentElement = $(document);

  documentElement.on('scroll', function() {
    // Quando o usuário rolar até o ponto da div 'about', a classe 'visible' será adicionada
    if (documentElement.scrollTop() > aboutElementOffset) {
      aboutElement.addClass("visible");
      
       $('.image').each(function(index) {
        setTimeout(() => {
          $(this).addClass("visible");
        }, index * 300); // Cria um efeito de animação em sequência
      });
    }
  });
});
  